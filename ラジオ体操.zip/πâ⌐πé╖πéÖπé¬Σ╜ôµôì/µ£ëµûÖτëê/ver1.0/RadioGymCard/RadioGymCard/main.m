//
//  main.m
//  nend
//
//  Created by エスエスシー パソナテック on 12/07/09.
//  Copyright (c) 2012年 株式会社パソナテック. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "AppDelegate.h"

int main(int argc, char *argv[])
{
   @autoreleasepool {
       return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
   }
}
